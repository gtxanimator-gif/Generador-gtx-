# Anime Sketch Studio

Frontend estático para GitHub Pages: sube un boceto o dibuja directamente en el lienzo, elige un estilo artístico y envía la imagen a un endpoint de generación.

## Incluye

- Canvas para dibujar con ratón, táctil o lápiz.
- Subida de PNG/JPG/WebP con drag & drop.
- Vista previa en vivo del dibujo.
- Galería de estilos.
- Controles de fidelidad y detalle.
- Opciones para preservar pose, rostro y lineart.
- UI responsive para móvil.
- Modo demo: si `/api/generate` no existe, muestra el boceto como resultado.
- Preparado para conectar un backend de IA sin exponer claves en GitHub Pages.

## GitHub Pages

1. Crea un repositorio.
2. Sube `index.html`, `style.css` y `app.js`.
3. En **Settings → Pages**, publica desde la rama principal.
4. La interfaz funcionará como frontend.

> Importante: GitHub Pages es estático. No pongas una API key privada dentro de `app.js`. Para generación real usa un backend/serverless y deja en el frontend únicamente la URL del endpoint.

## Endpoint esperado

`POST /api/generate`

Body JSON:
```json
{
  "image": "data:image/png;base64,...",
  "prompt": "descripción",
  "style": "Anime moderno",
  "strength": 75,
  "detail": 80,
  "preservePose": true,
  "preserveFace": true,
  "lineart": true
}
```

Respuesta:
```json
{ "image": "data:image/png;base64,..." }
```

También se acepta `{ "url": "https://..." }`.

## Próximo paso recomendado

Conectar `/api/generate` a un proveedor de generación de imágenes compatible con image-to-image/control de boceto. El frontend ya envía el boceto, prompt, estilo y parámetros.
