const canvas=document.getElementById("drawCanvas");
const ctx=canvas.getContext("2d");
const hint=document.getElementById("canvasHint");
const fileInput=document.getElementById("fileInput");
const dropzone=document.getElementById("dropzone");
let drawing=false,lastX=0,lastY=0,tool="brush",history=[],selectedStyle="Anime moderno";

ctx.fillStyle="#f2f2f4";ctx.fillRect(0,0,canvas.width,canvas.height);
function saveState(){history.push(ctx.getImageData(0,0,canvas.width,canvas.height));if(history.length>20)history.shift()}
function pos(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height}}
function start(e){drawing=true;saveState();const p=pos(e);lastX=p.x;lastY=p.y;hint.style.display="none";live("dibujando...")}
function move(e){if(!drawing)return;const p=pos(e);ctx.lineCap="round";ctx.lineJoin="round";ctx.lineWidth=+document.getElementById("brushSize").value;ctx.strokeStyle=tool==="eraser"?"#f2f2f4":"#1a1b21";ctx.globalCompositeOperation=tool==="eraser"?"destination-out":"source-over";ctx.beginPath();ctx.moveTo(lastX,lastY);ctx.lineTo(p.x,p.y);ctx.stroke();lastX=p.x;lastY=p.y;live("actualizando vista previa…")}
function end(){drawing=false;ctx.globalCompositeOperation="source-over";live("listo para generar")}
canvas.addEventListener("pointerdown",start);canvas.addEventListener("pointermove",move);canvas.addEventListener("pointerup",end);canvas.addEventListener("pointerleave",end);
function live(t){document.getElementById("liveText").textContent=t}

document.querySelectorAll(".tool[data-tool]").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tool[data-tool]").forEach(x=>x.classList.remove("active"));b.classList.add("active");tool=b.dataset.tool});
document.getElementById("undoBtn").onclick=()=>{if(history.length){ctx.putImageData(history.pop(),0,0);live("trazo deshecho")}};

fileInput.onchange=e=>loadFile(e.target.files[0]);
dropzone.addEventListener("dragover",e=>{e.preventDefault();dropzone.style.borderColor="#b78cff"});
dropzone.addEventListener("dragleave",()=>dropzone.style.borderColor="");
dropzone.addEventListener("drop",e=>{e.preventDefault();dropzone.style.borderColor="";loadFile(e.dataTransfer.files[0])});
function loadFile(file){if(!file||!file.type.startsWith("image/"))return;const img=new Image();img.onload=()=>{ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle="#f2f2f4";ctx.fillRect(0,0,canvas.width,canvas.height);const s=Math.min(canvas.width/img.width,canvas.height/img.height);const w=img.width*s,h=img.height*s;ctx.drawImage(img,(canvas.width-w)/2,(canvas.height-h)/2,w,h);hint.style.display="none";live("boceto cargado")};img.src=URL.createObjectURL(file)}

document.getElementById("clearBtn").onclick=()=>{ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle="#f2f2f4";ctx.fillRect(0,0,canvas.width,canvas.height);hint.style.display="grid";history=[];live("esperando trazos…")};
document.getElementById("strength").oninput=e=>document.getElementById("strengthOut").textContent=e.target.value+"%";
document.getElementById("detail").oninput=e=>document.getElementById("detailOut").textContent=e.target.value+"%";

const styles=[
["Anime moderno","Lineart limpio · sombreado suave","anime-modern"],
["Cel shading","Sombras gráficas · colores vivos","cel"],
["Acuarela anime","Textura pictórica · tonos suaves","watercolor"],
["Manga","Blanco y negro · tinta definida","manga"],
["Fantasy","Épico · iluminación mágica","fantasy"],
["Retro anime","Paleta vintage · grano sutil","retro"]
];
const grid=document.getElementById("styleGrid");
styles.forEach(([name,desc,cls])=>{const el=document.createElement("button");el.className="style-item"+(name===selectedStyle?" selected":"");el.innerHTML=`<div class="style-thumb ${cls}"></div><div class="style-info"><b>${name}</b><small>${desc}</small></div>`;el.onclick=()=>selectStyle(name,cls,desc,el);grid.appendChild(el)});
function selectStyle(name,cls,desc,el){selectedStyle=name;document.querySelectorAll(".style-item").forEach(x=>x.classList.remove("selected"));el.classList.add("selected");document.getElementById("selectedStyle").textContent="Elegido: "+name;document.querySelector(".selected-card").innerHTML=`<div class="style-preview ${cls}"></div><div><b>${name}</b><small>${desc}</small></div>`}
document.querySelectorAll(".tab").forEach(t=>t.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".tab-panel").forEach(x=>x.classList.remove("active"));t.classList.add("active");document.getElementById(t.dataset.tab+"Panel").classList.add("active")});

document.getElementById("generateBtn").onclick=async()=>{
 const btn=document.getElementById("generateBtn");btn.disabled=true;btn.textContent="✦ Generando…";
 const data=canvas.toDataURL("image/png");
 try{
   const res=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
     image:data,prompt:document.getElementById("prompt").value,style:selectedStyle,
     strength:+document.getElementById("strength").value,detail:+document.getElementById("detail").value,
     preservePose:document.getElementById("preservePose").checked,preserveFace:document.getElementById("preserveFace").checked,lineart:document.getElementById("lineart").checked
   })});
   if(!res.ok) throw new Error("API no conectada");
   const out=await res.json();showResult(out.image||out.url);
 }catch(err){
   // Demo visual: usa el boceto como resultado mientras no exista backend.
   showResult(data);
   document.getElementById("statusDot").style.background="#ffcc66";
   live("modo demo: conecta /api/generate para IA real");
 }
 btn.disabled=false;btn.textContent="✦ Convertir a anime";
};
function showResult(src){const img=document.getElementById("resultImage");img.src=src;img.hidden=false;document.getElementById("resultPlaceholder").hidden=true;document.querySelector('[data-tab="result"]').click()}

document.getElementById("themeBtn").onclick=()=>document.body.classList.toggle("light");
